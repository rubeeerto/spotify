import asyncio
from aiogram import Bot, Dispatcher, types
from aiogram.filters import Command
from handlers.download_handler import handle_spotify_links

BOT_TOKEN = "ВАШ_ТОКЕН"

bot = Bot(token=BOT_TOKEN)
dp = Dispatcher()

@dp.message(Command("start"))
async def start(message: types.Message):
    await message.answer("Привіт! Надішли посилання на трек або плейлист Spotify, я його скачаю!")

@dp.message()
async def msg_handler(message: types.Message):
    await handle_spotify_links(message, bot)

if __name__ == "__main__":
    asyncio.run(dp.start_polling(bot))
