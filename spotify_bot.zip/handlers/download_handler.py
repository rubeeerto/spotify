import os
import asyncio
import logging
from spotipy import Spotify
from spotipy.oauth2 import SpotifyClientCredentials
from aiogram import types
from aiogram.types import FSInputFile
import yt_dlp
from pydub import AudioSegment

# Налаштування Spotify
SPOTIFY_CLIENT_ID = "8cf672fedd5b4fcd90430f12cd80f2d1" 
SPOTIFY_CLIENT_SECRET = "28ac385824814fcf942961dfc75f727e"

spotify = Spotify(auth_manager=SpotifyClientCredentials(
    client_id=SPOTIFY_CLIENT_ID,
    client_secret=SPOTIFY_CLIENT_SECRET
))

# Логи
logging.basicConfig(level=logging.INFO)
logger = logging.getLogger(__name__)

DOWNLOADS_DIR = "downloads"
os.makedirs(DOWNLOADS_DIR, exist_ok=True)

async def download_youtube_by_search(track_name: str):
    filename_template = os.path.join(DOWNLOADS_DIR, "%(title)s.%(ext)s")
    ydl_opts = {
        "format": "bestaudio/best",
        "quiet": True,
        "noplaylist": True,
        "outtmpl": filename_template,
        "postprocessors": [{
            "key": "FFmpegExtractAudio",
            "preferredcodec": "mp3",
            "preferredquality": "192",
        }],
    }
    loop = asyncio.get_event_loop()
    info = await loop.run_in_executor(None, lambda: yt_dlp.YoutubeDL(ydl_opts).extract_info(f"ytsearch:{track_name}", download=True))
    title = info['entries'][0]['title']
    file_path = os.path.join(DOWNLOADS_DIR, f"{title}.mp3")
    return file_path, title

async def compress_if_needed(file_path: str):
    size_mb = os.path.getsize(file_path) / (1024 * 1024)
    if size_mb > 50:
        compressed_path = file_path.rsplit(".", 1)[0] + "_compressed.mp3"
        AudioSegment.from_file(file_path).export(compressed_path, format="mp3", bitrate="128k")
        os.remove(file_path)
        return compressed_path
    return file_path

async def handle_spotify_links(message: types.Message, bot):
    url = message.text.strip()
    msg = await message.answer("⏳ Аналізую посилання...")
    
    try:
        if "playlist" in url:
            playlist = spotify.playlist_tracks(url)
            for item in playlist['items']:
                track = item['track']
                track_name = f"{track['name']} {track['artists'][0]['name']}"
                await msg.edit_text(f"⏳ Качаю трек: {track_name}")
                file_path, title = await download_youtube_by_search(track_name)
                file_path = await compress_if_needed(file_path)
                await message.answer_audio(FSInputFile(file_path, filename=f"{title}.mp3"))
                os.remove(file_path)
        else:
            track = spotify.track(url)
            track_name = f"{track['name']} {track['artists'][0]['name']}"
            await msg.edit_text(f"⏳ Качаю трек: {track_name}")
            file_path, title = await download_youtube_by_search(track_name)
            file_path = await compress_if_needed(file_path)
            await message.answer_audio(FSInputFile(file_path, filename=f"{title}.mp3"))
            os.remove(file_path)
    except Exception as e:
        logger.error(f"Помилка при скачуванні: {e}")
        await msg.edit_text(f"❌ Помилка: {e}")
